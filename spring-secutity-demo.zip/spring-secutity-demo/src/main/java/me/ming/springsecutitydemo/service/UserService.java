package me.ming.springsecutitydemo.service;

import me.ming.springsecutitydemo.model.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
public class UserService implements UserDetailsService {

    public void addUser(){}     // 正常的业务方法

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        /*
        *  正常逻辑
        *  return getUserByUsername(s) 数据库方法
        * */
        User user = new User();

        user.setId("admin");
        user.setPassword("admin");

        Set<GrantedAuthority> permissions = new HashSet<>();

        permissions.add(new SimpleGrantedAuthority("query"));
        permissions.add(new SimpleGrantedAuthority("base"));

        return user;
    }
}
