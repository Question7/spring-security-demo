package me.ming.springsecutitydemo.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

    @RequestMapping(value = "/api/data", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public String addData() {
        return "success";
    }

    @RequestMapping(value = "/api/data", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public String queryData() {
        return "data";
    }

    @RequestMapping(value = "/home", produces = MediaType.APPLICATION_JSON_VALUE)
    public String test() {
        return "home";
    }
}
